/*
  # Create Quiz Stats and Activity Tracking Tables

  1. New Tables
    - `quiz_stats`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `total_points` (integer, default 0)
      - `streak_days` (integer, default 0)
      - `accuracy` (decimal, default 0)
      - `quizzes_completed` (integer, default 0)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    - `quiz_activity`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `article_id` (text)
      - `article_title` (text)
      - `points_earned` (integer, default 0)
      - `correct` (boolean, default false)
      - `created_at` (timestamptz)
    - `leaderboard`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `display_name` (text)
      - `total_points` (integer, default 0)
      - `streak_days` (integer, default 0)
      - `rank` (integer)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Users can read their own quiz_stats
    - Users can read their own quiz_activity
    - Users can insert their own quiz_activity
    - Leaderboard is readable by all authenticated users
    - Users can update their own quiz_stats and leaderboard entries
*/

CREATE TABLE IF NOT EXISTS quiz_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  total_points integer DEFAULT 0,
  streak_days integer DEFAULT 0,
  accuracy decimal DEFAULT 0,
  quizzes_completed integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE quiz_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own quiz stats"
  ON quiz_stats FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own quiz stats"
  ON quiz_stats FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own quiz stats"
  ON quiz_stats FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS quiz_activity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  article_id text NOT NULL,
  article_title text NOT NULL,
  points_earned integer DEFAULT 0,
  correct boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE quiz_activity ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own quiz activity"
  ON quiz_activity FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own quiz activity"
  ON quiz_activity FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS leaderboard (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL,
  total_points integer DEFAULT 0,
  streak_days integer DEFAULT 0,
  rank integer,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE leaderboard ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read leaderboard"
  ON leaderboard FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own leaderboard entry"
  ON leaderboard FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own leaderboard entry"
  ON leaderboard FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
