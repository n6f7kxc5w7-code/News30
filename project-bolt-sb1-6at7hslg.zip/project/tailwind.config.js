/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ytbg: '#0f0f0f',
        ytcard: '#272727',
        ytchip: '#272727',
        ytchipActive: '#f1f1f1',
        ytchipText: '#f1f1f1',
        ytchipActiveText: '#0f0f0f',
        ytsearch: '#121212',
        ytsearchBorder: '#303030',
        ythover: '#272727',
        yttext: '#f1f1f1',
        yttextSec: '#aaaaaa',
        ytblue: '#3ea6ff',
        ytred: '#ff0000',
        ytdivider: '#272727',
      },
      fontFamily: {
        roboto: ['Roboto', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
