export interface NewsArticle {
  id: string;
  title: string;
  source: string;
  verified: boolean;
  timestamp: string;
  duration: string;
  category: string;
  avatarColor: string;
  thumbnailGradient: string;
  summary: string;
  keyPoints: string[];
  sourceLinks: { label: string; url: string }[];
  quiz: QuizQuestion[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  points: number;
}

const avatarColors = ['#ff4444', '#44aaff', '#44ff88', '#ffaa44', '#aa44ff', '#ff44aa', '#44ffaa', '#ff8844'];

const gradients = [
  'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
  'linear-gradient(135deg, #1a0a2e 0%, #2d1b4e 50%, #44318d 100%)',
  'linear-gradient(135deg, #0a1a2e 0%, #1b2d4e 50%, #314475 100%)',
  'linear-gradient(135deg, #2e1a0a 0%, #4e2d1b 50%, #754431 100%)',
  'linear-gradient(135deg, #0a2e1a 0%, #1b4e2d 50%, #317544 100%)',
  'linear-gradient(135deg, #2e0a1a 0%, #4e1b2d 50%, #753144 100%)',
  'linear-gradient(135deg, #1a2e0a 0%, #2d4e1b 50%, #447531 100%)',
  'linear-gradient(135deg, #0a2e2e 0%, #1b4e4e 50%, #317575 100%)',
];

export const categories = ['All', 'Geopolitics', 'Finance', 'Sports', 'Technology', 'Science', 'Local', 'Culture'];
export const proCategories = ['Technology', 'Science', 'Local', 'Culture'];

export const mockArticles: NewsArticle[] = [
  {
    id: '1',
    title: 'G7 Summit Agrees on New Sanctions Package Targeting Energy Sector',
    source: 'Reuters',
    verified: true,
    timestamp: '2 hours ago',
    duration: '8:24',
    category: 'Geopolitics',
    avatarColor: avatarColors[0],
    thumbnailGradient: gradients[0],
    summary: 'The G7 nations have agreed on a comprehensive sanctions package targeting Russia\'s energy sector, including a price cap on oil and restrictions on natural gas imports. The agreement was reached after intense negotiations during the three-day summit in Hiroshima.',
    keyPoints: [
      'New price cap on Russian oil set at $60 per barrel',
      'Phased ban on natural gas imports by 2027',
      'Additional sanctions on Russian diamond exports',
      'Commitment to accelerate renewable energy transition',
    ],
    sourceLinks: [
      { label: 'Reuters Full Report', url: '#' },
      { label: 'G7 Official Statement', url: '#' },
    ],
    quiz: [
      { id: 'q1', question: 'What is the new price cap on Russian oil?', options: ['$50 per barrel', '$60 per barrel', '$70 per barrel', '$80 per barrel'], correctIndex: 1, points: 10 },
      { id: 'q2', question: 'By what year is the phased ban on natural gas imports planned?', options: ['2025', '2026', '2027', '2028'], correctIndex: 2, points: 10 },
    ],
  },
  {
    id: '2',
    title: 'Federal Reserve Signals Potential Rate Cuts in September Meeting',
    source: 'Bloomberg',
    verified: true,
    timestamp: '4 hours ago',
    duration: '12:05',
    category: 'Finance',
    avatarColor: avatarColors[1],
    thumbnailGradient: gradients[1],
    summary: 'Federal Reserve Chair Jerome Powell indicated that the central bank could begin cutting interest rates as early as September, citing progress on inflation and a cooling labor market.',
    keyPoints: [
      'Fed signals September as potential start for rate cuts',
      'Inflation has dropped to 2.4% annually',
      'Labor market showing signs of gradual cooling',
      'Markets rally on the announcement',
    ],
    sourceLinks: [
      { label: 'Bloomberg Analysis', url: '#' },
      { label: 'Fed Official Statement', url: '#' },
    ],
    quiz: [
      { id: 'q3', question: 'What is the current annual inflation rate mentioned?', options: ['2.1%', '2.4%', '2.7%', '3.0%'], correctIndex: 1, points: 10 },
      { id: 'q4', question: 'When did the Fed signal potential rate cuts?', options: ['July', 'August', 'September', 'October'], correctIndex: 2, points: 10 },
    ],
  },
  {
    id: '3',
    title: 'Champions League Final: Real Madrid Clinch Record 16th Title',
    source: 'ESPN',
    verified: true,
    timestamp: '6 hours ago',
    duration: '5:30',
    category: 'Sports',
    avatarColor: avatarColors[2],
    thumbnailGradient: gradients[2],
    summary: 'Real Madrid secured their 16th Champions League title with a dramatic 2-1 victory over Manchester City at Wembley Stadium, with Vinicius Jr scoring the winner in the 89th minute.',
    keyPoints: [
      'Real Madrid wins 16th Champions League title',
      'Vinicius Jr scores 89th minute winner',
      'Manchester City\'s quest for second title continues',
      'Record attendance of 90,000 at Wembley',
    ],
    sourceLinks: [
      { label: 'ESPN Match Report', url: '#' },
      { label: 'UEFA Official', url: '#' },
    ],
    quiz: [
      { id: 'q5', question: 'How many Champions League titles has Real Madrid won?', options: ['14', '15', '16', '17'], correctIndex: 2, points: 10 },
      { id: 'q6', question: 'Who scored the winning goal?', options: ['Bellingham', 'Vinicius Jr', 'Mbappe', 'Rodrygo'], correctIndex: 1, points: 10 },
    ],
  },
  {
    id: '4',
    title: 'NATO Allies Commit to 2.5% GDP Defense Spending Target',
    source: 'BBC News',
    verified: true,
    timestamp: '8 hours ago',
    duration: '10:15',
    category: 'Geopolitics',
    avatarColor: avatarColors[3],
    thumbnailGradient: gradients[3],
    summary: 'NATO members have agreed to raise their defense spending target to 2.5% of GDP, up from the current 2% commitment, in response to growing security threats from Russia and China.',
    keyPoints: [
      'New 2.5% GDP defense spending target agreed',
      'Previous target was 2% of GDP',
      'Driven by security concerns over Russia and China',
      'Implementation timeline set for 2030',
    ],
    sourceLinks: [
      { label: 'BBC Full Coverage', url: '#' },
      { label: 'NATO Press Release', url: '#' },
    ],
    quiz: [
      { id: 'q7', question: 'What is the new NATO defense spending target?', options: ['2% GDP', '2.5% GDP', '3% GDP', '3.5% GDP'], correctIndex: 1, points: 10 },
      { id: 'q8', question: 'By what year should the new target be implemented?', options: ['2028', '2029', '2030', '2031'], correctIndex: 2, points: 10 },
    ],
  },
  {
    id: '5',
    title: 'S&P 500 Hits Record High as Tech Stocks Surge',
    source: 'CNBC',
    verified: true,
    timestamp: '3 hours ago',
    duration: '7:45',
    category: 'Finance',
    avatarColor: avatarColors[4],
    thumbnailGradient: gradients[4],
    summary: 'The S&P 500 reached a new all-time high driven by strong earnings from major tech companies, with AI-related stocks leading the rally. NVIDIA alone gained 8% after reporting record quarterly revenue.',
    keyPoints: [
      'S&P 500 reaches new all-time high',
      'AI stocks lead the market rally',
      'NVIDIA gains 8% on record revenue',
      'Analysts remain cautiously optimistic',
    ],
    sourceLinks: [
      { label: 'CNBC Market Update', url: '#' },
      { label: 'NVIDIA Earnings Report', url: '#' },
    ],
    quiz: [
      { id: 'q9', question: 'Which stock gained 8% after reporting record revenue?', options: ['Apple', 'Microsoft', 'NVIDIA', 'Google'], correctIndex: 2, points: 10 },
      { id: 'q10', question: 'What type of stocks led the rally?', options: ['Energy stocks', 'AI-related stocks', 'Banking stocks', 'Healthcare stocks'], correctIndex: 1, points: 10 },
    ],
  },
  {
    id: '6',
    title: 'Olympic Committee Announces New Sports for 2028 Los Angeles Games',
    source: 'The Athletic',
    verified: true,
    timestamp: '5 hours ago',
    duration: '6:20',
    category: 'Sports',
    avatarColor: avatarColors[5],
    thumbnailGradient: gradients[5],
    summary: 'The International Olympic Committee has confirmed five new sports for the 2028 Los Angeles Olympics, including flag football, cricket, lacrosse, squash, and baseball/softball.',
    keyPoints: [
      'Five new sports added for 2028 Olympics',
      'Flag football makes its Olympic debut',
      'Cricket returns after 128-year absence',
      'Lacrosse included for first time since 1908',
    ],
    sourceLinks: [
      { label: 'The Athletic Report', url: '#' },
      { label: 'IOC Announcement', url: '#' },
    ],
    quiz: [
      { id: 'q11', question: 'How many new sports were added for 2028?', options: ['3', '4', '5', '6'], correctIndex: 2, points: 10 },
      { id: 'q12', question: 'Which sport returns after 128 years?', options: ['Lacrosse', 'Cricket', 'Squash', 'Baseball'], correctIndex: 1, points: 10 },
    ],
  },
  {
    id: '7',
    title: 'EU Passes Landmark AI Regulation Framework',
    source: 'TechCrunch',
    verified: true,
    timestamp: '1 hour ago',
    duration: '15:30',
    category: 'Technology',
    avatarColor: avatarColors[6],
    thumbnailGradient: gradients[6],
    summary: 'The European Union has passed the world\'s most comprehensive AI regulation framework, categorizing AI systems by risk level and imposing strict requirements on high-risk applications.',
    keyPoints: [
      'EU passes comprehensive AI Act',
      'AI systems categorized by risk level',
      'High-risk AI requires transparency and audits',
      'Fines up to 7% of global revenue for violations',
    ],
    sourceLinks: [
      { label: 'TechCrunch Analysis', url: '#' },
      { label: 'EU AI Act Full Text', url: '#' },
    ],
    quiz: [
      { id: 'q13', question: 'How are AI systems categorized under the new framework?', options: ['By cost', 'By risk level', 'By company size', 'By country of origin'], correctIndex: 1, points: 10 },
      { id: 'q14', question: 'What is the maximum fine for violations?', options: ['3% of revenue', '5% of revenue', '7% of revenue', '10% of revenue'], correctIndex: 2, points: 10 },
    ],
  },
  {
    id: '8',
    title: 'NASA Confirms Water Ice Deposits at Lunar South Pole',
    source: 'Space.com',
    verified: true,
    timestamp: '7 hours ago',
    duration: '9:10',
    category: 'Science',
    avatarColor: avatarColors[7],
    thumbnailGradient: gradients[7],
    summary: 'NASA has confirmed significant water ice deposits at the lunar south pole using data from the Lunar Reconnaissance Orbiter, a finding that could support future human settlements on the Moon.',
    keyPoints: [
      'Water ice confirmed at lunar south pole',
      'Data from Lunar Reconnaissance Orbiter',
      'Could support future human settlements',
      'Artemis program to send crew by 2026',
    ],
    sourceLinks: [
      { label: 'Space.com Coverage', url: '#' },
      { label: 'NASA Official Release', url: '#' },
    ],
    quiz: [
      { id: 'q15', question: 'What spacecraft provided the data for this discovery?', options: ['James Webb', 'Lunar Reconnaissance Orbiter', 'Hubble', 'Artemis I'], correctIndex: 1, points: 10 },
      { id: 'q16', question: 'When does the Artemis program plan to send crew?', options: ['2025', '2026', '2027', '2028'], correctIndex: 1, points: 10 },
    ],
  },
  {
    id: '9',
    title: 'Major Earthquake Strikes Pacific Ring of Fire Region',
    source: 'Al Jazeera',
    verified: true,
    timestamp: '30 minutes ago',
    duration: '4:55',
    category: 'Local',
    avatarColor: avatarColors[0],
    thumbnailGradient: gradients[0],
    summary: 'A 7.2 magnitude earthquake struck the Pacific Ring of Fire region, triggering tsunami warnings across multiple countries. Emergency response teams have been deployed.',
    keyPoints: [
      '7.2 magnitude earthquake recorded',
      'Tsunami warnings issued for Pacific nations',
      'Emergency response teams deployed',
      'No casualties reported so far',
    ],
    sourceLinks: [
      { label: 'Al Jazeera Live Updates', url: '#' },
      { label: 'USGS Report', url: '#' },
    ],
    quiz: [
      { id: 'q17', question: 'What was the magnitude of the earthquake?', options: ['6.2', '6.8', '7.2', '7.8'], correctIndex: 2, points: 10 },
      { id: 'q18', question: 'What warnings were triggered?', options: ['Tornado warnings', 'Tsunami warnings', 'Volcano warnings', 'Flood warnings'], correctIndex: 1, points: 10 },
    ],
  },
  {
    id: '10',
    title: 'Venice Biennale Showcases AI-Generated Art Controversy',
    source: 'The Guardian',
    verified: true,
    timestamp: '9 hours ago',
    duration: '11:40',
    category: 'Culture',
    avatarColor: avatarColors[1],
    thumbnailGradient: gradients[1],
    summary: 'The Venice Biennale has sparked heated debate by featuring AI-generated art alongside traditional works, raising questions about creativity, authorship, and the future of artistic expression.',
    keyPoints: [
      'AI-generated art featured at Venice Biennale',
      'Debate over creativity and authorship',
      'Traditional artists voice concerns',
      'Exhibition draws record attendance',
    ],
    sourceLinks: [
      { label: 'The Guardian Review', url: '#' },
      { label: 'Venice Biennale Official', url: '#' },
    ],
    quiz: [
      { id: 'q19', question: 'What controversy surrounds the Venice Biennale?', options: ['Censorship issues', 'AI-generated art inclusion', 'Budget overruns', 'Political statements'], correctIndex: 1, points: 10 },
      { id: 'q20', question: 'What has the exhibition drawn?', options: ['Protests', 'Record attendance', 'Legal challenges', 'Government intervention'], correctIndex: 1, points: 10 },
    ],
  },
  {
    id: '11',
    title: 'India and China Reach Border De-escalation Agreement',
    source: 'NDTV',
    verified: true,
    timestamp: '12 hours ago',
    duration: '14:20',
    category: 'Geopolitics',
    avatarColor: avatarColors[2],
    thumbnailGradient: gradients[2],
    summary: 'India and China have reached a breakthrough agreement on border de-escalation in the Ladakh region, with both sides agreeing to withdraw troops from contested areas and establish a buffer zone.',
    keyPoints: [
      'Border de-escalation agreement reached',
      'Both sides to withdraw troops from contested areas',
      'Buffer zone to be established',
      'Diplomatic talks to continue',
    ],
    sourceLinks: [
      { label: 'NDTV Coverage', url: '#' },
      { label: 'Ministry of External Affairs', url: '#' },
    ],
    quiz: [
      { id: 'q21', question: 'Which region is the focus of the de-escalation?', options: ['Kashmir', 'Ladakh', 'Sikkim', 'Arunachal Pradesh'], correctIndex: 1, points: 10 },
      { id: 'q22', question: 'What will be established between the two sides?', options: ['Trade zone', 'Buffer zone', 'Military base', 'Observation post'], correctIndex: 1, points: 10 },
    ],
  },
  {
    id: '12',
    title: 'Global Crypto Market Cap Surpasses $4 Trillion',
    source: 'CoinDesk',
    verified: true,
    timestamp: '1 hour ago',
    duration: '6:50',
    category: 'Finance',
    avatarColor: avatarColors[3],
    thumbnailGradient: gradients[3],
    summary: 'The global cryptocurrency market capitalization has surpassed $4 trillion for the first time, driven by Bitcoin\'s surge past $120,000 and growing institutional adoption.',
    keyPoints: [
      'Crypto market cap exceeds $4 trillion',
      'Bitcoin surpasses $120,000',
      'Institutional adoption accelerates',
      'Regulatory clarity improves in major markets',
    ],
    sourceLinks: [
      { label: 'CoinDesk Analysis', url: '#' },
      { label: 'Market Data', url: '#' },
    ],
    quiz: [
      { id: 'q23', question: 'What milestone did the crypto market cap surpass?', options: ['$2 trillion', '$3 trillion', '$4 trillion', '$5 trillion'], correctIndex: 2, points: 10 },
      { id: 'q24', question: 'What price did Bitcoin surpass?', options: ['$100,000', '$110,000', '$120,000', '$130,000'], correctIndex: 2, points: 10 },
    ],
  },
];
