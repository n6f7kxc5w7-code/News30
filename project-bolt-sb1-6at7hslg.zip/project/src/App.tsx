import { useState, useMemo } from 'react';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import CategoryChips from './components/CategoryChips';
import NewsGrid from './components/NewsGrid';
import ShortsPlayer from './components/ShortsPlayer';
import SideDrawer from './components/SideDrawer';
import { mockArticles, NewsArticle } from './data/mockData';

function App() {
  const [sidebarCollapsed] = useState(true);
  const [activeSidebarItem, setActiveSidebarItem] = useState('home');
  const [activeCategory, setActiveCategory] = useState('All');
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const filteredArticles = useMemo(() => {
    if (activeCategory === 'All') return mockArticles;
    return mockArticles.filter((a) => a.category === activeCategory);
  }, [activeCategory]);

  const handleMenuClick = () => {
    setDrawerOpen(true);
  };

  const handleSidebarItemClick = (item: string) => {
    setActiveSidebarItem(item);
  };

  const handleArticleClick = (article: NewsArticle) => {
    setSelectedArticle(article);
  };

  const mainMarginLeft = sidebarCollapsed ? 'ml-[72px]' : 'ml-[240px]';

  return (
    <div className="min-h-screen bg-ytbg font-roboto">
      <Navbar onMenuClick={handleMenuClick} />

      <Sidebar
        collapsed={sidebarCollapsed}
        activeItem={activeSidebarItem}
        onItemClick={handleSidebarItemClick}
      />

      <main className={`pt-14 ${mainMarginLeft} transition-all duration-200`}>
        <div className="px-6 py-4">
          <CategoryChips activeCategory={activeCategory} onCategoryClick={setActiveCategory} />
          <NewsGrid articles={filteredArticles} onArticleClick={handleArticleClick} />
        </div>
      </main>

      {selectedArticle && (
        <ShortsPlayer article={selectedArticle} onClose={() => setSelectedArticle(null)} />
      )}

      <SideDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} />
    </div>
  );
}

export default App;
