import { useState } from 'react';
import { ArrowLeft, ThumbsUp, Bot, HelpCircle, Share2 } from 'lucide-react';
import { NewsArticle } from '../data/mockData';
import SummaryPanel from './SummaryPanel';
import AskAIPanel from './AskAIPanel';
import QuizPanel from './QuizPanel';

interface ShortsPlayerProps {
  article: NewsArticle;
  onClose: () => void;
}

type Tab = 'summary' | 'askai' | 'quiz';

export default function ShortsPlayer({ article, onClose }: ShortsPlayerProps) {
  const [activeTab, setActiveTab] = useState<Tab>('summary');
  const [panelOpen, setPanelOpen] = useState(false);
  const [liked, setLiked] = useState(false);

  const handleTabClick = (tab: Tab) => {
    if (activeTab === tab && panelOpen) {
      setPanelOpen(false);
    } else {
      setActiveTab(tab);
      setPanelOpen(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-ytbg flex flex-col">
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-2 flex-shrink-0">
        <button onClick={onClose} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-ythover transition-colors">
          <ArrowLeft size={20} className="text-yttext" />
        </button>
        <span className="text-yttext text-sm font-medium">News30</span>
        <div className="w-10" />
      </div>

      {/* Main content area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Video area */}
        <div className="flex-1 flex items-center justify-center relative">
          <div
            className="w-full h-full max-w-[400px] max-h-[700px] rounded-xl overflow-hidden relative mx-auto"
            style={{ background: article.thumbnailGradient }}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <div className="flex items-center gap-2 mb-2">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold"
                  style={{ backgroundColor: article.avatarColor }}
                >
                  {article.source[0]}
                </div>
                <span className="text-white text-sm font-medium">{article.source}</span>
              </div>
              <h2 className="text-white text-base font-medium leading-snug">{article.title}</h2>
            </div>
          </div>

          {/* Right side action buttons */}
          <div className="absolute right-4 bottom-24 flex flex-col items-center gap-5">
            <button
              onClick={() => setLiked(!liked)}
              className="flex flex-col items-center gap-1"
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${liked ? 'bg-ytblue/20' : 'bg-white/10'}`}>
                <ThumbsUp size={22} className={liked ? 'text-ytblue' : 'text-white'} fill={liked ? 'currentColor' : 'none'} />
              </div>
              <span className="text-white text-[11px]">{liked ? '1' : '0'}</span>
            </button>
            <button
              onClick={() => handleTabClick('askai')}
              className="flex flex-col items-center gap-1"
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${activeTab === 'askai' && panelOpen ? 'bg-ytblue/20' : 'bg-white/10'}`}>
                <Bot size={22} className={activeTab === 'askai' && panelOpen ? 'text-ytblue' : 'text-white'} />
              </div>
              <span className="text-white text-[11px]">Ask AI</span>
            </button>
            <button
              onClick={() => handleTabClick('quiz')}
              className="flex flex-col items-center gap-1"
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${activeTab === 'quiz' && panelOpen ? 'bg-ytblue/20' : 'bg-white/10'}`}>
                <HelpCircle size={22} className={activeTab === 'quiz' && panelOpen ? 'text-ytblue' : 'text-white'} />
              </div>
              <span className="text-white text-[11px]">Quiz</span>
            </button>
            <button className="flex flex-col items-center gap-1">
              <div className="w-10 h-10 rounded-full flex items-center justify-center bg-white/10">
                <Share2 size={22} className="text-white" />
              </div>
              <span className="text-white text-[11px]">Share</span>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom tabs */}
      <div className="flex-shrink-0 border-t border-ytdivider">
        <div className="flex">
          <button
            onClick={() => handleTabClick('summary')}
            className={`flex-1 py-3 text-sm font-medium transition-colors ${
              activeTab === 'summary' && panelOpen ? 'text-yttext border-b-2 border-yttext' : 'text-yttextSec'
            }`}
          >
            Summary
          </button>
          <button
            onClick={() => handleTabClick('askai')}
            className={`flex-1 py-3 text-sm font-medium transition-colors ${
              activeTab === 'askai' && panelOpen ? 'text-yttext border-b-2 border-yttext' : 'text-yttextSec'
            }`}
          >
            Ask AI
          </button>
          <button
            onClick={() => handleTabClick('quiz')}
            className={`flex-1 py-3 text-sm font-medium transition-colors ${
              activeTab === 'quiz' && panelOpen ? 'text-yttext border-b-2 border-yttext' : 'text-yttextSec'
            }`}
          >
            Quiz
          </button>
        </div>
      </div>

      {/* Slide-up panel */}
      <div
        className={`fixed bottom-0 left-0 right-0 bg-ytcard rounded-t-2xl transition-transform duration-300 ease-out z-60 ${
          panelOpen ? 'translate-y-0' : 'translate-y-full'
        }`}
        style={{ maxHeight: '60vh', bottom: '48px' }}
      >
        <div className="overflow-y-auto p-5 scrollbar-hide" style={{ maxHeight: 'calc(60vh - 20px)' }}>
          {activeTab === 'summary' && <SummaryPanel article={article} />}
          {activeTab === 'askai' && <AskAIPanel article={article} />}
          {activeTab === 'quiz' && <QuizPanel article={article} />}
        </div>
      </div>
    </div>
  );
}
