import { useState } from 'react';
import { CheckCircle, XCircle, Trophy } from 'lucide-react';
import { NewsArticle } from '../data/mockData';

interface QuizPanelProps {
  article: NewsArticle;
}

export default function QuizPanel({ article }: QuizPanelProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(false);
  const [quizComplete, setQuizComplete] = useState(false);

  const question = article.quiz[currentQuestion];

  const handleAnswer = (index: number) => {
    if (answered) return;
    setSelectedAnswer(index);
    setAnswered(true);
    if (index === question.correctIndex) {
      setScore((prev) => prev + question.points);
    }
  };

  const handleNext = () => {
    if (currentQuestion < article.quiz.length - 1) {
      setCurrentQuestion((prev) => prev + 1);
      setSelectedAnswer(null);
      setAnswered(false);
    } else {
      setQuizComplete(true);
    }
  };

  if (quizComplete) {
    const maxScore = article.quiz.reduce((sum, q) => sum + q.points, 0);
    const percentage = Math.round((score / maxScore) * 100);
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <div className="w-16 h-16 rounded-full bg-ytblue/20 flex items-center justify-center mb-4">
          <Trophy size={28} className="text-ytblue" />
        </div>
        <h3 className="text-yttext text-lg font-medium mb-1">Quiz Complete!</h3>
        <p className="text-yttextSec text-sm mb-4">
          You scored <span className="text-ytblue font-bold">{score}</span> out of {maxScore} points
        </p>
        <div className="w-32 h-32 rounded-full border-4 border-ytblue flex items-center justify-center mb-4">
          <span className="text-yttext text-2xl font-bold">{percentage}%</span>
        </div>
        <button
          onClick={() => {
            setCurrentQuestion(0);
            setSelectedAnswer(null);
            setAnswered(false);
            setScore(0);
            setQuizComplete(false);
          }}
          className="px-6 py-2 bg-ytblue text-ytchipActiveText rounded-full text-sm font-medium hover:bg-ytblue/80 transition-colors"
        >
          Retry Quiz
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-yttextSec text-xs">
          Question {currentQuestion + 1} of {article.quiz.length}
        </span>
        <span className="text-ytblue text-xs font-medium">{score} pts</span>
      </div>

      <div className="w-full bg-ytchip rounded-full h-1.5">
        <div
          className="bg-ytblue h-1.5 rounded-full transition-all duration-300"
          style={{ width: `${((currentQuestion + (answered ? 1 : 0)) / article.quiz.length) * 100}%` }}
        />
      </div>

      <h3 className="text-yttext text-base font-medium">{question.question}</h3>

      <div className="space-y-2">
        {question.options.map((option, index) => {
          const isCorrect = index === question.correctIndex;
          const isSelected = index === selectedAnswer;
          let buttonClass = 'bg-ytchip border border-ytsearchBorder text-yttext hover:bg-ythover';

          if (answered) {
            if (isCorrect) {
              buttonClass = 'bg-green-900/40 border border-green-500/50 text-green-400';
            } else if (isSelected && !isCorrect) {
              buttonClass = 'bg-red-900/40 border border-red-500/50 text-red-400';
            } else {
              buttonClass = 'bg-ytchip/50 border border-ytsearchBorder text-yttextSec';
            }
          }

          return (
            <button
              key={index}
              onClick={() => handleAnswer(index)}
              disabled={answered}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-left transition-all ${buttonClass}`}
            >
              <span className="w-6 h-6 rounded-full border border-current flex items-center justify-center text-xs font-medium flex-shrink-0">
                {String.fromCharCode(65 + index)}
              </span>
              <span className="flex-1">{option}</span>
              {answered && isCorrect && <CheckCircle size={18} className="text-green-400 flex-shrink-0" />}
              {answered && isSelected && !isCorrect && <XCircle size={18} className="text-red-400 flex-shrink-0" />}
            </button>
          );
        })}
      </div>

      {answered && (
        <button
          onClick={handleNext}
          className="w-full py-2.5 bg-ytblue text-ytchipActiveText rounded-full text-sm font-medium hover:bg-ytblue/80 transition-colors"
        >
          {currentQuestion < article.quiz.length - 1 ? 'Next Question' : 'See Results'}
        </button>
      )}
    </div>
  );
}
