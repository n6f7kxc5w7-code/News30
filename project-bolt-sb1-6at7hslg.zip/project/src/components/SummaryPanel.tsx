import { ExternalLink } from 'lucide-react';
import { NewsArticle } from '../data/mockData';

interface SummaryPanelProps {
  article: NewsArticle;
}

export default function SummaryPanel({ article }: SummaryPanelProps) {
  return (
    <div className="space-y-5">
      <div>
        <h3 className="text-yttext text-base font-medium mb-2">Summary</h3>
        <p className="text-yttextSec text-sm leading-relaxed">{article.summary}</p>
      </div>

      <div>
        <h3 className="text-yttext text-base font-medium mb-2">Key Points</h3>
        <ul className="space-y-2">
          {article.keyPoints.map((point, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-yttextSec">
              <span className="w-1.5 h-1.5 rounded-full bg-ytblue mt-1.5 flex-shrink-0" />
              {point}
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h3 className="text-yttext text-base font-medium mb-2">Sources</h3>
        <div className="space-y-2">
          {article.sourceLinks.map((link, i) => (
            <a
              key={i}
              href={link.url}
              className="flex items-center gap-2 text-sm text-ytblue hover:underline"
            >
              <ExternalLink size={14} />
              {link.label}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
