import { Menu, Search, Bell, Video, UserCircle } from 'lucide-react';

interface NavbarProps {
  onMenuClick: () => void;
}

export default function Navbar({ onMenuClick }: NavbarProps) {
  return (
    <nav className="fixed top-0 left-0 right-0 h-14 bg-ytbg z-50 flex items-center justify-between px-4">
      <div className="flex items-center gap-4 min-w-[200px]">
        <button
          onClick={onMenuClick}
          className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-ythover transition-colors"
        >
          <Menu size={20} className="text-yttext" />
        </button>
        <div className="flex items-center gap-0.5 cursor-pointer">
          <div className="relative flex items-center">
            <span className="text-ytred text-xl font-bold tracking-tight">N</span>
          </div>
          <span className="text-yttext text-xl font-bold tracking-tight ml-0.5">News30</span>
        </div>
      </div>

      <div className="flex items-center flex-1 max-w-[640px] mx-auto">
        <div className="flex flex-1 items-center">
          <div className="flex flex-1 items-center bg-ytsearch border border-ytsearchBorder rounded-l-full px-4 h-10 focus-within:border-ytblue">
            <input
              type="text"
              placeholder="Search"
              className="bg-transparent outline-none text-yttext text-base w-full placeholder:text-yttextSec"
            />
          </div>
          <button className="h-10 px-5 bg-ytsearch border border-l-0 border-ytsearchBorder rounded-r-full hover:bg-ythover transition-colors">
            <Search size={18} className="text-yttext" />
          </button>
        </div>
      </div>

      <div className="flex items-center gap-2 min-w-[200px] justify-end">
        <button className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-ythover transition-colors">
          <Video size={20} className="text-yttext" />
        </button>
        <button className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-ythover transition-colors relative">
          <Bell size={20} className="text-yttext" />
          <span className="absolute top-1 right-1 w-3 h-3 bg-ytred rounded-full text-[8px] flex items-center justify-center text-white font-medium">3</span>
        </button>
        <button className="ml-2 flex items-center gap-2 px-4 py-2 border border-ytblue rounded-full text-ytblue text-sm font-medium hover:bg-ytblue/10 transition-colors">
          <UserCircle size={18} />
          Sign in
        </button>
      </div>
    </nav>
  );
}
