import { Home, TrendingUp, Bookmark, Bot, FileText } from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  activeItem: string;
  onItemClick: (item: string) => void;
}

const sidebarItems = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'trending', label: 'Trending', icon: TrendingUp },
  { id: 'saved', label: 'Saved Stories', icon: Bookmark },
  { id: 'askai', label: 'Ask AI', icon: Bot },
  { id: 'simplify', label: 'Simplify Article', icon: FileText },
];

export default function Sidebar({ collapsed, activeItem, onItemClick }: SidebarProps) {
  if (collapsed) {
    return (
      <aside className="fixed left-0 top-14 w-[72px] h-[calc(100vh-56px)] bg-ytbg z-40 overflow-y-auto scrollbar-hide">
        <div className="flex flex-col items-center pt-1 pb-4">
          {sidebarItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeItem === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onItemClick(item.id)}
                className={`flex flex-col items-center justify-center w-full py-4 px-1 gap-1.5 transition-colors ${
                  isActive ? 'bg-ythover' : 'hover:bg-ythover'
                }`}
              >
                <Icon size={20} className={isActive ? 'text-yttext' : 'text-yttextSec'} />
                <span className={`text-[10px] leading-tight ${isActive ? 'text-yttext' : 'text-yttextSec'}`}>
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </aside>
    );
  }

  return (
    <aside className="fixed left-0 top-14 w-[240px] h-[calc(100vh-56px)] bg-ytbg z-40 overflow-y-auto scrollbar-hide border-r border-ytdivider/50">
      <div className="flex flex-col py-3">
        {sidebarItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeItem === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onItemClick(item.id)}
              className={`flex items-center gap-6 px-6 py-2.5 text-sm transition-colors ${
                isActive ? 'bg-ythover text-yttext font-medium' : 'text-yttextSec hover:bg-ythover'
              }`}
            >
              <Icon size={20} className={isActive ? 'text-yttext' : 'text-yttextSec'} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
      <div className="border-t border-ytdivider/50 mx-3 my-2" />
      <div className="px-6 py-3">
        <p className="text-xs text-yttextSec leading-relaxed">
          News30 delivers the top 30 news stories in 30-second summaries. Stay informed, stay ahead.
        </p>
      </div>
    </aside>
  );
}
