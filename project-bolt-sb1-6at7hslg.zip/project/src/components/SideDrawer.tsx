import { useState } from 'react';
import { X, Trophy, Clock, BarChart3, Bot, Settings, ChevronRight, Flame, Target, Award } from 'lucide-react';

interface SideDrawerProps {
  open: boolean;
  onClose: () => void;
}

type DrawerTab = 'stats' | 'activity' | 'leaderboard' | 'askai' | 'settings';

const tabs = [
  { id: 'stats' as DrawerTab, label: 'Quiz Stats', icon: Trophy },
  { id: 'activity' as DrawerTab, label: 'Activity', icon: Clock },
  { id: 'leaderboard' as DrawerTab, label: 'Leaderboard', icon: BarChart3 },
  { id: 'askai' as DrawerTab, label: 'Ask AI', icon: Bot },
  { id: 'settings' as DrawerTab, label: 'Settings', icon: Settings },
];

const leaderboardData = [
  { rank: 1, name: 'Sarah K.', points: 1240, streak: 15 },
  { rank: 2, name: 'Mike R.', points: 1180, streak: 12 },
  { rank: 3, name: 'Priya S.', points: 1050, streak: 10 },
  { rank: 4, name: 'James L.', points: 980, streak: 8 },
  { rank: 5, name: 'Yuki T.', points: 920, streak: 7 },
];

const activityData = [
  { title: 'G7 Summit Sanctions Quiz', points: 20, time: '2h ago', correct: true },
  { title: 'Fed Rate Cuts Quiz', points: 10, time: '4h ago', correct: true },
  { title: 'Champions League Quiz', points: 0, time: '6h ago', correct: false },
  { title: 'NATO Defense Quiz', points: 20, time: '8h ago', correct: true },
  { title: 'S&P 500 Quiz', points: 10, time: '1d ago', correct: true },
];

export default function SideDrawer({ open, onClose }: SideDrawerProps) {
  const [activeTab, setActiveTab] = useState<DrawerTab>('stats');

  if (!open) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/60 z-50" onClick={onClose} />
      <div className="fixed left-0 top-0 bottom-0 w-[320px] bg-ytbg z-50 flex flex-col animate-slide-in">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-ytdivider/50">
          <h2 className="text-yttext text-base font-medium">Menu</h2>
          <button onClick={onClose} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-ythover transition-colors">
            <X size={18} className="text-yttext" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex overflow-x-auto scrollbar-hide border-b border-ytdivider/50">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-3 text-xs font-medium whitespace-nowrap border-b-2 transition-colors ${
                  isActive ? 'text-yttext border-yttext' : 'text-yttextSec border-transparent hover:text-yttext'
                }`}
              >
                <Icon size={14} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 scrollbar-hide">
          {activeTab === 'stats' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-ytcard rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Target size={16} className="text-ytblue" />
                    <span className="text-yttextSec text-xs">Total Points</span>
                  </div>
                  <p className="text-yttext text-2xl font-bold">580</p>
                </div>
                <div className="bg-ytcard rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Flame size={16} className="text-orange-500" />
                    <span className="text-yttextSec text-xs">Streak</span>
                  </div>
                  <p className="text-yttext text-2xl font-bold">7 days</p>
                </div>
                <div className="bg-ytcard rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Award size={16} className="text-green-500" />
                    <span className="text-yttextSec text-xs">Accuracy</span>
                  </div>
                  <p className="text-yttext text-2xl font-bold">78%</p>
                </div>
                <div className="bg-ytcard rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Trophy size={16} className="text-yellow-500" />
                    <span className="text-yttextSec text-xs">Rank</span>
                  </div>
                  <p className="text-yttext text-2xl font-bold">#42</p>
                </div>
              </div>
              <div className="bg-ytcard rounded-xl p-4">
                <h4 className="text-yttext text-sm font-medium mb-3">Category Performance</h4>
                <div className="space-y-3">
                  {['Geopolitics', 'Finance', 'Sports'].map((cat) => (
                    <div key={cat}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-yttextSec">{cat}</span>
                        <span className="text-yttext">{Math.floor(Math.random() * 30 + 70)}%</span>
                      </div>
                      <div className="w-full bg-ytbg rounded-full h-1.5">
                        <div className="bg-ytblue h-1.5 rounded-full" style={{ width: `${Math.floor(Math.random() * 30 + 70)}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'activity' && (
            <div className="space-y-2">
              {activityData.map((item, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-ytcard rounded-xl">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${item.correct ? 'bg-green-900/40' : 'bg-red-900/40'}`}>
                    {item.correct ? <CheckCircle size={14} className="text-green-400" /> : <XCircle size={14} className="text-red-400" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-yttext text-sm truncate">{item.title}</p>
                    <p className="text-yttextSec text-xs">{item.time}</p>
                  </div>
                  <span className={`text-sm font-medium ${item.points > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    +{item.points}
                  </span>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'leaderboard' && (
            <div className="space-y-2">
              {leaderboardData.map((user) => (
                <div key={user.rank} className="flex items-center gap-3 p-3 bg-ytcard rounded-xl">
                  <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                    user.rank === 1 ? 'bg-yellow-500/20 text-yellow-500' :
                    user.rank === 2 ? 'bg-gray-400/20 text-gray-400' :
                    user.rank === 3 ? 'bg-orange-500/20 text-orange-500' :
                    'bg-ytchip text-yttextSec'
                  }`}>
                    {user.rank}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-yttext text-sm font-medium">{user.name}</p>
                    <p className="text-yttextSec text-xs">{user.points} pts / {user.streak} day streak</p>
                  </div>
                  <ChevronRight size={16} className="text-yttextSec" />
                </div>
              ))}
            </div>
          )}

          {activeTab === 'askai' && (
            <div className="space-y-4">
              <div className="bg-ytcard rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Bot size={18} className="text-ytblue" />
                  <h4 className="text-yttext text-sm font-medium">News30 AI Assistant</h4>
                </div>
                <p className="text-yttextSec text-sm leading-relaxed">
                  Ask me about any news topic and I'll help you understand it better. I can simplify complex articles, provide context, and answer your questions.
                </p>
              </div>
              <div className="space-y-2">
                {['What happened at the G7 Summit?', 'Explain the Fed rate decision', 'Who won the Champions League?'].map((q, i) => (
                  <button key={i} className="w-full text-left px-4 py-3 bg-ytcard rounded-xl text-sm text-yttextSec hover:bg-ythover transition-colors">
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-3">
              {[
                { label: 'Notifications', desc: 'Breaking news alerts' },
                { label: 'Dark Mode', desc: 'Always on' },
                { label: 'Auto-play', desc: 'Play next story automatically' },
                { label: 'Quiz Difficulty', desc: 'Medium' },
                { label: 'Language', desc: 'English' },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-ytcard rounded-xl">
                  <div>
                    <p className="text-yttext text-sm">{item.label}</p>
                    <p className="text-yttextSec text-xs">{item.desc}</p>
                  </div>
                  <ChevronRight size={16} className="text-yttextSec" />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

function CheckCircle({ size, className }: { size: number; className: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
      <polyline points="22 4 12 14.01 9 11.01"/>
    </svg>
  );
}

function XCircle({ size, className }: { size: number; className: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <circle cx="12" cy="12" r="10"/>
      <line x1="15" y1="9" x2="9" y2="15"/>
      <line x1="9" y1="9" x2="15" y2="15"/>
    </svg>
  );
}
