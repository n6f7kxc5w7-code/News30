import { NewsArticle } from '../data/mockData';
import NewsCard from './NewsCard';

interface NewsGridProps {
  articles: NewsArticle[];
  onArticleClick: (article: NewsArticle) => void;
}

export default function NewsGrid({ articles, onArticleClick }: NewsGridProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-8">
      {articles.map((article) => (
        <NewsCard key={article.id} article={article} onClick={onArticleClick} />
      ))}
    </div>
  );
}
