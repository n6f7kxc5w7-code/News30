import { useState } from 'react';
import { Send, Bot, User } from 'lucide-react';
import { NewsArticle } from '../data/mockData';

interface AskAIPanelProps {
  article: NewsArticle;
}

interface Message {
  id: string;
  role: 'user' | 'ai';
  content: string;
}

const aiResponses: Record<string, string> = {
  default: "Based on this article, I can help you understand the key details. The main takeaway is that this is a developing story with significant implications. Would you like me to elaborate on any specific aspect?",
  explain: "Let me break this down in simpler terms: This article discusses an important development that could affect multiple stakeholders. The key factors to consider are the economic impact, political implications, and long-term consequences.",
  more: "Here's additional context: This story connects to broader trends we've been tracking. Similar developments have occurred in the past, but this particular event stands out because of its scale and the speed at which it unfolded.",
};

export default function AskAIPanel({ article }: AskAIPanelProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '0',
      role: 'ai',
      content: `I've analyzed "${article.title}". Ask me anything about this story and I'll help you understand it better.`,
    },
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
    };

    const aiMsg: Message = {
      id: (Date.now() + 1).toString(),
      role: 'ai',
      content: aiResponses[Math.random() > 0.5 ? 'explain' : 'more'] || aiResponses.default,
    };

    setMessages([...messages, userMsg, aiMsg]);
    setInput('');
  };

  return (
    <div className="flex flex-col h-[40vh]">
      <div className="flex-1 overflow-y-auto space-y-3 mb-3 scrollbar-hide">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.role === 'ai' && (
              <div className="w-7 h-7 rounded-full bg-ytblue/20 flex items-center justify-center flex-shrink-0">
                <Bot size={14} className="text-ytblue" />
              </div>
            )}
            <div
              className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-ytblue text-ytchipActiveText rounded-br-sm'
                  : 'bg-ytchip text-yttext rounded-bl-sm'
              }`}
            >
              {msg.content}
            </div>
            {msg.role === 'user' && (
              <div className="w-7 h-7 rounded-full bg-ytchip flex items-center justify-center flex-shrink-0">
                <User size={14} className="text-yttextSec" />
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="flex items-center gap-2">
        <div className="flex-1 flex items-center bg-ytsearch border border-ytsearchBorder rounded-full px-4 py-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about this article..."
            className="bg-transparent outline-none text-yttext text-sm w-full placeholder:text-yttextSec"
          />
        </div>
        <button
          onClick={handleSend}
          className="w-9 h-9 rounded-full bg-ytblue flex items-center justify-center hover:bg-ytblue/80 transition-colors"
        >
          <Send size={16} className="text-ytchipActiveText" />
        </button>
      </div>
    </div>
  );
}
