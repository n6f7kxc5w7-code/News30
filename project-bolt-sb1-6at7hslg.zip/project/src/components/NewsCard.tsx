import { CheckCircle, HelpCircle } from 'lucide-react';
import { NewsArticle } from '../data/mockData';

interface NewsCardProps {
  article: NewsArticle;
  onClick: (article: NewsArticle) => void;
}

export default function NewsCard({ article, onClick }: NewsCardProps) {
  return (
    <div
      className="cursor-pointer group"
      onClick={() => onClick(article)}
    >
      <div className="relative w-full aspect-video rounded-xl overflow-hidden mb-3">
        <div
          className="w-full h-full flex items-center justify-center"
          style={{ background: article.thumbnailGradient }}
        >
          <div className="w-12 h-12 rounded-full bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="w-0 h-0 border-t-[8px] border-t-transparent border-b-[8px] border-b-transparent border-l-[14px] border-l-white ml-1" />
          </div>
        </div>
        <span className="absolute bottom-1.5 right-1.5 bg-black/80 text-white text-xs font-medium px-1.5 py-0.5 rounded">
          {article.duration}
        </span>
      </div>
      <div className="flex gap-3">
        <div
          className="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center text-white text-xs font-bold"
          style={{ backgroundColor: article.avatarColor }}
        >
          {article.source[0]}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-medium text-yttext leading-5 line-clamp-2 mb-1">
            {article.title}
          </h3>
          <div className="flex items-center gap-1 text-xs text-yttextSec">
            <span>{article.source}</span>
            {article.verified && <CheckCircle size={12} className="text-yttextSec" />}
            <span className="before:content-['·'] before:mx-1">{article.timestamp}</span>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); onClick(article); }}
            className="mt-1.5 flex items-center gap-1 px-2 py-0.5 bg-black/60 border border-white/10 rounded text-[11px] text-yttextSec hover:text-yttext hover:border-white/20 transition-colors"
          >
            <HelpCircle size={11} />
            Quiz
          </button>
        </div>
      </div>
    </div>
  );
}
