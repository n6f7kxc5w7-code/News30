import { Lock } from 'lucide-react';
import { categories, proCategories } from '../data/mockData';

interface CategoryChipsProps {
  activeCategory: string;
  onCategoryClick: (category: string) => void;
}

export default function CategoryChips({ activeCategory, onCategoryClick }: CategoryChipsProps) {
  return (
    <div className="flex items-center gap-3 overflow-x-auto scrollbar-hide py-3 px-1">
      {categories.map((category) => {
        const isPro = proCategories.includes(category);
        const isActive = activeCategory === category;
        return (
          <button
            key={category}
            onClick={() => !isPro && onCategoryClick(category)}
            disabled={isPro}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
              isPro
                ? 'bg-ytchip/60 text-yttextSec cursor-not-allowed border border-ytsearchBorder'
                : isActive
                ? 'bg-ytchipActive text-ytchipActiveText'
                : 'bg-ytchip text-ytchipText hover:bg-ythover'
            }`}
          >
            {isPro && <Lock size={12} />}
            {category}
            {isPro && <span className="text-[10px] text-ytblue font-bold ml-0.5">PRO</span>}
          </button>
        );
      })}
    </div>
  );
}
